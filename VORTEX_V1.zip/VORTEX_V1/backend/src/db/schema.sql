CREATE TABLE users(id SERIAL PRIMARY KEY, username TEXT, email TEXT, password_hash TEXT, role TEXT);
CREATE TABLE products(id SERIAL PRIMARY KEY, name TEXT, price DECIMAL, stock INT);
CREATE TABLE orders(id SERIAL PRIMARY KEY, user_id INT, product_id INT, status TEXT);
CREATE TABLE logs(id SERIAL PRIMARY KEY, action TEXT, created_at TIMESTAMP DEFAULT NOW());
