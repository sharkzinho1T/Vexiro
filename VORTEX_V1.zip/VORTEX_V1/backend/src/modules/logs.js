// Logs administrativos
