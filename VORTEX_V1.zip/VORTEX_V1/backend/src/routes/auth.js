// Registro, login, JWT e recuperação de senha
