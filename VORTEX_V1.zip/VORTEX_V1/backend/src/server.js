const express = require('express');
const app = express();
app.use(express.json());
app.get('/', (req,res)=>res.json({status:'VORTEX online'}));
app.listen(3000);
